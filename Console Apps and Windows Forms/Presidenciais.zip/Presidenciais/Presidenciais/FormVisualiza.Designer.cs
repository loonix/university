﻿namespace Presidenciais
{
    partial class FormVisualiza
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Distrito = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MarceloRDS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SampaioDN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MarisaMatias = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VitorioSilva = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MariaBelem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PauloMorais = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EdgarSilva = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HenriqueNeto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JorgeSequeira = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CandidoFerreira = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Brancos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nulos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Distrito,
            this.MarceloRDS,
            this.SampaioDN,
            this.MarisaMatias,
            this.VitorioSilva,
            this.MariaBelem,
            this.PauloMorais,
            this.EdgarSilva,
            this.HenriqueNeto,
            this.JorgeSequeira,
            this.CandidoFerreira,
            this.Brancos,
            this.Nulos});
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1046, 314);
            this.dataGridView1.TabIndex = 0;
            // 
            // Distrito
            // 
            this.Distrito.HeaderText = "Distrito";
            this.Distrito.Name = "Distrito";
            // 
            // MarceloRDS
            // 
            this.MarceloRDS.HeaderText = "Marcelo Rabelo de Sousa";
            this.MarceloRDS.Name = "MarceloRDS";
            // 
            // SampaioDN
            // 
            this.SampaioDN.HeaderText = "Sampaio da Novoa";
            this.SampaioDN.Name = "SampaioDN";
            // 
            // MarisaMatias
            // 
            this.MarisaMatias.HeaderText = "Marisa Matias";
            this.MarisaMatias.Name = "MarisaMatias";
            // 
            // VitorioSilva
            // 
            this.VitorioSilva.HeaderText = "Vitorio Silva";
            this.VitorioSilva.Name = "VitorioSilva";
            // 
            // MariaBelem
            // 
            this.MariaBelem.HeaderText = "Maria Belem";
            this.MariaBelem.Name = "MariaBelem";
            // 
            // PauloMorais
            // 
            this.PauloMorais.HeaderText = "Paulo Morais";
            this.PauloMorais.Name = "PauloMorais";
            // 
            // EdgarSilva
            // 
            this.EdgarSilva.HeaderText = "Edgar Silva";
            this.EdgarSilva.Name = "EdgarSilva";
            // 
            // HenriqueNeto
            // 
            this.HenriqueNeto.HeaderText = "Henrique Neto";
            this.HenriqueNeto.Name = "HenriqueNeto";
            // 
            // JorgeSequeira
            // 
            this.JorgeSequeira.HeaderText = "Jorge Sequeira";
            this.JorgeSequeira.Name = "JorgeSequeira";
            // 
            // CandidoFerreira
            // 
            this.CandidoFerreira.HeaderText = "Candido Ferreira";
            this.CandidoFerreira.Name = "CandidoFerreira";
            // 
            // Brancos
            // 
            this.Brancos.HeaderText = "Brancos";
            this.Brancos.Name = "Brancos";
            // 
            // Nulos
            // 
            this.Nulos.HeaderText = "Nulos";
            this.Nulos.Name = "Nulos";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(836, 380);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(139, 35);
            this.button1.TabIndex = 1;
            this.button1.Text = "Sair";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // FormVisualiza
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1070, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "FormVisualiza";
            this.Text = "FormVisualiza";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Distrito;
        private System.Windows.Forms.DataGridViewTextBoxColumn MarceloRDS;
        private System.Windows.Forms.DataGridViewTextBoxColumn SampaioDN;
        private System.Windows.Forms.DataGridViewTextBoxColumn MarisaMatias;
        private System.Windows.Forms.DataGridViewTextBoxColumn VitorioSilva;
        private System.Windows.Forms.DataGridViewTextBoxColumn MariaBelem;
        private System.Windows.Forms.DataGridViewTextBoxColumn PauloMorais;
        private System.Windows.Forms.DataGridViewTextBoxColumn EdgarSilva;
        private System.Windows.Forms.DataGridViewTextBoxColumn HenriqueNeto;
        private System.Windows.Forms.DataGridViewTextBoxColumn JorgeSequeira;
        private System.Windows.Forms.DataGridViewTextBoxColumn CandidoFerreira;
        private System.Windows.Forms.DataGridViewTextBoxColumn Brancos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nulos;
        private System.Windows.Forms.Button button1;
    }
}