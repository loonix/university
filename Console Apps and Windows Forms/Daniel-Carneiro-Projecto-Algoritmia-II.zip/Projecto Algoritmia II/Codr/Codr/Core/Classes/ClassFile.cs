﻿using System;

namespace Codr.Core.Classes
{
    public class ClassFile
    {
        public static string rootPath = AppDomain.CurrentDomain.BaseDirectory;
        public static string filesFolder = @rootPath + "Core\\Files\\";
    }
}
