﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Data;
using System.Collections.ObjectModel;

namespace CamadaNegocio
{
    public class Country : Notifier
    {
        #region Construtores

        public Country()
        { 
        }

        public Country(string codigo, string desc)
        {
            this.countryCode = codigo;
            this.countryName = desc;
        }
        #endregion

        #region Propriedades

        private string countryCode;
        public string CountryCode
        {
            get { return this.countryCode; }
            set
            {
                this.countryCode = value;
                this.OnPropertyChanged("CountryCode");
            }
        }

        private string countryName;
        public string CountryName
        {
            get { return countryName; }
            set
            {
                this.countryName = value;
                this.OnPropertyChanged("CountryName");
            }
        }

        #endregion

        #region Metodos

        public static DataTable ObterLista()
        {
            return CamadaDados.Country.ObterLista();
        }

        public IList<string> ObterCountries()
        {
            List<string> lista = new List<string>();
            DataTable dataTable = CamadaDados.Country.ObterLista();

            foreach (DataRow item in dataTable.AsEnumerable())
            {
                string nome = item.Field<string>("CountryCode");

                lista.Add(nome);
            }

            return lista;
        }

        public static CountryCollection ObterListaCountries()
        {
            DataTable dataTable = Country.ObterLista();

            CountryCollection codigos = new CountryCollection(dataTable);

            return codigos;
        }

        public void Novo()
        {
            this.CountryCode = string.Empty;
            this.CountryName = string.Empty;
        }

        public bool Eliminar(ref string sErro)
        {
            return CamadaDados.Country.Eliminar(this.CountryCode, ref sErro);
        }

        #endregion
    }

    public class CountryCollection : Collection<Country>, INotifyPropertyChanged
    {
        #region Construtores

        public CountryCollection()
        {
        }

        public CountryCollection(DataTable dataTable)
        {
            foreach (DataRow item in dataTable.AsEnumerable())
            {
                Country country = new Country();
                country.CountryCode = item.Field<string>("CountryCode");
                country.CountryName = item.Field<string>("CountryName");

                this.Add(country);
            }
        }

        #endregion

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(
                    this,
                    new PropertyChangedEventArgs(propertyName)
                    );
            }
        }
    }

}
