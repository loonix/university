﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TagPII
{
    /// <summary>
    /// Interaction logic for Sede.xaml
    /// </summary>
    public partial class Cluster : Window
    {
        public Cluster()
        {
            InitializeComponent();
        }
        
        #region Propriedades

        public CamadaNegocio.Cluster Conteudo { get; set; }

        #endregion

        #region Metodos

        private void NovoRegisto()
        {
            CamadaNegocio.Cluster continente = (CamadaNegocio.Cluster)this.DataContext;
            continente.Novo();
        }

        private void GravarRegisto()
        {
            string sErro = string.Empty;
            CamadaNegocio.Cluster cluster = (CamadaNegocio.Cluster)this.DataContext;

            if (cluster.Gravar(ref sErro))
            {
                MessageBox.Show("Gravado com sucesso.");
            }
            else
            {
                MessageBox.Show(string.Format("Erro {0}", sErro));
            }
        }

        private void EliminarRegisto()
        {
            string sErro = string.Empty;
            CamadaNegocio.Cluster codigo = (CamadaNegocio.Cluster)this.DataContext;

            if (codigo.Eliminar(ref sErro))
            {
                MessageBox.Show(Properties.Resources.REGISTO_ELIMINADO);
            }
            else
            {
                MessageBox.Show(string.Format("Erro {0}", sErro));
            }
        }
        #endregion

        #region Eventos

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = new CamadaNegocio.Cluster();
        }

        private void MenuNovo_Click(object sender, RoutedEventArgs e)
        {
            this.NovoRegisto();
        }
        
        private void MenuGravar_Click(object sender, RoutedEventArgs e)
        {
            this.GravarRegisto();
        }

        private void MenuEliminar_Click(object sender, RoutedEventArgs e)
        {
            this.EliminarRegisto();
        }

        private void MenuSair_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        #endregion

    }
}
