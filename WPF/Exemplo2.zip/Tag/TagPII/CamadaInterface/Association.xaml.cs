﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace TagPII
{
    /// <summary>
    /// Interaction logic for Association.xaml
    /// </summary>
    public partial class Association : Window
    {
        public Association()
        {
            InitializeComponent();
            this.Conteudo = new CamadaNegocio.Association();
            this.DataContext = this.Conteudo;
        }

        #region Propriedades

        public CamadaNegocio.Association Conteudo { get; set; }

        #endregion

        #region Metodos

        private void MostrarAssociacao(int associationCode)
        {
            CamadaNegocio.Association associacao = CamadaNegocio.Association.ObterAssociacao(associationCode);
            if (associacao != null)
            {
                this.DataContext = associacao;
            }
            else
            {
                MessageBox.Show(Properties.Resources.REGISTO_NAO_EXISTE);
            }
        }
        
        #endregion

        private void SubmitProduct(object sender, RoutedEventArgs e)
        {
            this.GravarRegisto();
        }

        private void GravarRegisto()
        {
            string sErro = string.Empty;
            CamadaNegocio.Association association = (CamadaNegocio.Association)this.DataContext;

            if (association.Gravar(ref sErro))
            {
                MessageBox.Show("Gravado com sucesso.");
            }
            else
            {
                MessageBox.Show(string.Format("Erro {0}", sErro));
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void TextBoxAssociationCode_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                int associationCode = 0;
                if (int.TryParse(TextBoxAssociationCode.Text, out associationCode))
                {
                    this.MostrarAssociacao(associationCode);
                }
                else
                {
                    MessageBox.Show(Properties.Resources.REGISTO_NAO_EXISTE);
                }
            }
        }

    }
}
