﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Data;
using System.Collections.ObjectModel;

namespace CamadaNegocio
{
    public class Association : Notifier
    {
        
        #region Construtores

        public Association()
        { 
        }

        public Association(int associationCode, string associationNome, string countryCode, string clusterCode)
        {
            // TODO: Complete member initialization
            this.associationCode = associationCode;
            this.associationName = associationNome;
            this.countryCode = countryCode;
            this.clusterCode = clusterCode;
        }

        #endregion

        #region Propriedades

        private int associationCode;
        public int AssociationCode
        {
            get { return associationCode; }
            set
            {
                this.associationCode = value;
                this.OnPropertyChanged("AssociationCode");
            }
        }

        private string associationName;
        public string AssociationName
        {
            get { return associationName; }
            set
            {
                this.associationName = value;
                this.OnPropertyChanged("AssociationName");
            }
        }

        private string countryCode;
        public string CountryCode
        {
            get { return this.countryCode; }
            set
            {
                this.countryCode = value;
                this.OnPropertyChanged("CountryCode");
            }
        }

        private string clusterCode;
        public string ClusterCode
        {
            get { return clusterCode; }
            set
            {
                this.clusterCode = value;
                this.OnPropertyChanged("ClusterCode");
            }
        }

        private int memberNumbers;
        public int MemberNumbers
        {
            get { return this.memberNumbers; }
            set
            {
                this.memberNumbers = value;
                this.OnPropertyChanged("Ranking");
            }
        }
        #endregion

        #region Metodos

        public override string ToString()
        {
            return this.AssociationName;
        }

        public static DataTable ObterLista()
        {
            return CamadaDados.Association.ObterLista();
        }

        public static AssociationCollection ObterListaAssociacoes()
        {
            DataTable dataTable = Association.ObterLista();

            AssociationCollection associacoes = new AssociationCollection(dataTable);

            return associacoes;
        }

        public void Novo()
        {
            this.AssociationCode = 0;
            this.CountryCode = string.Empty;
            this.AssociationName = string.Empty;
            this.ClusterCode = string.Empty;
            this.MemberNumbers = 0;
        }

        public bool Gravar(ref string sErro)
        {
            return CamadaDados.Association.Gravar(this.AssociationCode, this.AssociationName
                , this.CountryCode, this.ClusterCode, this.MemberNumbers, ref sErro);
        }

        public bool Eliminar(ref string sErro)
        {
            return CamadaDados.Association.Eliminar(this.AssociationCode, ref sErro);
        }

        public static Association ObterAssociacao(int associationCode)
        {
            Association associacao = null;
            string associationName = string.Empty;
            string countryCode = string.Empty;
            string clusterCode = string.Empty;
            int memberNumbers = 0;
            string erro = string.Empty;

            if (CamadaDados.Association.ObterAssociation(associationCode, ref associationName, ref countryCode, ref clusterCode, ref memberNumbers, ref erro))
            {
                associacao = new Association(associationCode, associationName, countryCode, clusterCode);
                associacao.MemberNumbers = memberNumbers;
            }

            return associacao;
        }


        #endregion

    }

    public class AssociationCollection : Collection<Association>, INotifyPropertyChanged
    {
        #region Construtores

        public AssociationCollection()
        {
        }

        public AssociationCollection(DataTable dataTable)
        {
            if (dataTable == null)
                return;

            foreach (DataRow item in dataTable.AsEnumerable())
            {
                Association association = new Association();

                association.AssociationCode = item.Field<int>("AssociationCode");
                association.AssociationName = item.Field<string>("AssociationName");
                association.CountryCode = item.Field<string>("CountryCode");
                association.ClusterCode = item.Field<string>("ClusterCode");
                association.MemberNumbers = item.Field<int>("MemberNumbers");

                this.Add(association);
            }
        }

        #endregion

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(
                    this,
                    new PropertyChangedEventArgs(propertyName)
                    );
            }
        }
    }

}
