﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Data;
using System.Collections.ObjectModel;

namespace CamadaNegocio
{
    public enum EnumClusterType
    { 
        NotDefined = 0,
        Small = 1,
        Great = 2
    }

    public class Cluster : Notifier
    {
        #region Construtores

        public Cluster()
        { 
        }

        public Cluster(string custerCode, string clusterName, EnumClusterType clusterType)
        {
            this.clusterCode = custerCode;
            this.clusterName = clusterName;
            this.clusterType = clusterType;
        }
        #endregion

        #region Propriedades

        private string clusterCode;
        public string ClusterCode
        {
            get { return this.clusterCode; }
            set
            {
                this.clusterCode = value;
                this.OnPropertyChanged("ClusterCode");
            }
        }

        private string clusterName;
        public string ClusterName
        {
            get { return clusterName; }
            set
            {
                this.clusterName = value;
                this.OnPropertyChanged("ClusterName");
            }
        }

        private EnumClusterType clusterType;
        public EnumClusterType ClusterType
        {
            get { return clusterType; }
            set
            {
                this.clusterType = value;
                this.OnPropertyChanged("ClusterType");
            }
        }

        #endregion

        #region Metodos

        public static DataTable ObterLista()
        {
            return CamadaDados.Cluster.ObterLista();
        }

        public static ClusterCollection ObterListaClusters()
        {
            DataTable dataTable = Cluster.ObterLista();

            ClusterCollection clusters = new ClusterCollection(dataTable);

            return clusters;
        }

        public void Novo()
        {
            this.ClusterCode = string.Empty;
            this.ClusterName = string.Empty;
            this.ClusterType = CamadaNegocio.EnumClusterType.NotDefined;
        }

        public bool Eliminar(ref string sErro)
        {
            return CamadaDados.Cluster.Eliminar(this.ClusterCode, ref sErro);
        }

        public bool Gravar(ref string sErro)
        {
            return CamadaDados.Cluster.Gravar(this.ClusterCode, this.ClusterName, (int)this.ClusterType, ref sErro);
        }
        
        #endregion

    }

    public class ClusterCollection : Collection<Cluster>, INotifyPropertyChanged
    {
        #region Construtores

        public ClusterCollection()
        {
        }

        public ClusterCollection(DataTable dataTable)
        {
            foreach (DataRow item in dataTable.AsEnumerable())
            {
                Cluster cluster = new Cluster();
                cluster.ClusterCode = item.Field<string>("ClusterCode");
                cluster.ClusterName = item.Field<string>("ClusterName");
                cluster.ClusterType = (EnumClusterType)item.Field<int>("ClusterType");

                this.Add(cluster);
            }
        }

        #endregion

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(
                    this,
                    new PropertyChangedEventArgs(propertyName)
                    );
            }
        }
    }

}
