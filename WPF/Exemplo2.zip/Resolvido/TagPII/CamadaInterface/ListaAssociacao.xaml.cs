﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CamadaNegocio;

namespace TagPII
{
    /// <summary>
    /// Interaction logic for ListaAssociacao.xaml
    /// </summary>
    public partial class ListaAssociacao : Window
    {
        public ListaAssociacao()
        {
            InitializeComponent();
        }


        #region Propriedades

        public CamadaNegocio.Association association { get; set; }

        #endregion

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            AssociationCollection associations = CamadaNegocio.Association.ObterListaAssociacoes();
            listView1.ItemsSource = associations;
        }

        private void listView1_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            this.association = (CamadaNegocio.Association)listView1.SelectedItem;
            this.Close();
        }

    }
}
