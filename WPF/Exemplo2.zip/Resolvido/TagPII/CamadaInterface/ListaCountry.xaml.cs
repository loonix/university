﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TagPII
{
    /// <summary>
    /// Interaction logic for ListaCodigosPostais.xaml
    /// </summary>
    public partial class ListaCountry : Window
    {
        public ListaCountry()
        {
            InitializeComponent();
            this.list.DataContext = CamadaNegocio.Country.ObterListaCountries();
        }


        #region Propriedades

        public CamadaNegocio.Country CountrySelecionado { get; set; }

        #endregion

        private void list_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            this.CountrySelecionado = (CamadaNegocio.Country)list.SelectedItem;
            this.Close();
        }
    }
}
