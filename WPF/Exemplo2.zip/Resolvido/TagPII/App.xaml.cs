﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using System.Collections.ObjectModel;
using CamadaNegocio;

namespace TagPII
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        #region Propriedades

        private ObservableCollection<Country> countries = new ObservableCollection<Country>();

        public ObservableCollection<Country> Countries
        {
            get { return this.countries; }
            set { this.countries = value; }
        }

        #endregion
    }
}
