﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exercicio2.Controls
{
    /// <summary>
    /// Interaction logic for ControlNumerico.xaml
    /// </summary>
    public partial class ControlNumerico : UserControl
    {
        public ControlNumerico()
        {
            InitializeComponent();
        }

        /*
        private int numericValue;
        public int NumericValue 
        { 
            get
            {
                return this.numericValue;
            }
            set 
            {
                this.numericValue = value;
                this.TextBoxNumero.Text = this.numericValue.ToString(); 
            } 
        }
        */


        #region ValorNumerico

        /// <summary>
        /// Value Dependency Property
        /// </summary>
        public static readonly DependencyProperty ValorNumericoProperty =
            DependencyProperty.Register("ValorNumerico", typeof(int),
            typeof(ControlNumerico),
                new FrameworkPropertyMetadata((int)0,
                    new PropertyChangedCallback(OnValorNumericoChanged),
                    new CoerceValueCallback(CoerceValorNumericoValue)));

        /// <summary>
        /// Gets or sets the Value property.  
        /// </summary>
        public int ValorNumerico
        {
            get { return (int)GetValue(ValorNumericoProperty); }
            set 
            {
                SetValue(ValorNumericoProperty, value);
                this.TextBoxNumero.Text = value.ToString(); 
            }
        }

        /// <summary>
        /// Handles changes to the Value property.
        /// </summary>
        private static void OnValorNumericoChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            d.CoerceValue(MinimumProperty);
            d.CoerceValue(MaximumProperty);
            //RatingsControl ratingsControl = (RatingsControl)d;
            //SetupStars(ratingsControl);
            ControlNumerico controlNumerico = (ControlNumerico)d;

            controlNumerico.ValorNumerico = (int)e.NewValue;
        }

        /// <summary>
        /// Coerces the Value value.
        /// </summary>
        private static object CoerceValorNumericoValue(DependencyObject d, object value)
        {
            ControlNumerico controlNumerico = (ControlNumerico)d;
            int current = (int)value;
            if (current < controlNumerico.Minimum) current = controlNumerico.Minimum;
            if (current > controlNumerico.Maximum) current = controlNumerico.Maximum;
            return current;
        }
        #endregion


        #region Maximum

        /// <summary>
        /// Maximum Dependency Property
        /// </summary>
        public static readonly DependencyProperty MaximumProperty =
            DependencyProperty.Register("Maximum", typeof(Int32), typeof(ControlNumerico),
                new FrameworkPropertyMetadata((Int32)10));

        /// <summary>
        /// Gets or sets the Maximum property.  
        /// </summary>
        public Int32 Maximum
        {
            get { return (Int32)GetValue(MaximumProperty); }
            set { SetValue(MaximumProperty, value); }
        }

        #endregion

        #region Minimum

        /// <summary>
        /// Minimum Dependency Property
        /// </summary>
        public static readonly DependencyProperty MinimumProperty =
            DependencyProperty.Register("Minimum", typeof(Int32), typeof(ControlNumerico),
                new FrameworkPropertyMetadata((Int32)0));

        /// <summary>
        /// Gets or sets the Minimum property.  
        /// </summary>
        public Int32 Minimum
        {
            get { return (Int32)GetValue(MinimumProperty); }
            set { SetValue(MinimumProperty, value); }
        }

        #endregion

        private void Down_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            this.ValorNumerico--;
        }

        private void Up_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            this.ValorNumerico++;
        }


    }
}
