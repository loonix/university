﻿using CamadaNegocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TagPII.Controls
{
    /// <summary>
    /// Interaction logic for ControlClusteType.xaml
    /// </summary>
    public partial class ControlClusteType : UserControl
    {
        public ControlClusteType()
        {
            InitializeComponent();
        }

        #region ClusterType

        /// <summary>
        /// Value Dependency Property
        /// </summary>
        public static readonly DependencyProperty ClusterTypeProperty =
            DependencyProperty.Register("ClusterType", typeof(int),
                typeof(ControlClusteType),
                new FrameworkPropertyMetadata((EnumClusterType)0,
                new PropertyChangedCallback(OnClusterTypeChanged),
                new CoerceValueCallback(CoerceClusterTypeValue)));

        /// <summary>
        /// Gets or sets the Value property.  
        /// </summary>
        public EnumClusterType ClusterType
        {
            get { return (EnumClusterType)GetValue(ClusterTypeProperty); }
            set
            {
                SetValue(ClusterTypeProperty, value);
            }
        }

        /// <summary>
        /// Handles changes to the Value property.
        /// </summary>
        private static void OnClusterTypeChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            ControlClusteType ControlClusteType = (ControlClusteType)d;

            ControlClusteType.ClusterType = (EnumClusterType)e.NewValue;
        }

        /// <summary>
        /// Coerces the Value value.
        /// </summary>
        private static object CoerceClusterTypeValue(DependencyObject d, object value)
        {
            ControlClusteType ControlClusteType = (ControlClusteType)d;
            EnumClusterType current = (EnumClusterType)value;
  
            return current;
        }
        #endregion

    }
}
