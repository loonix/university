﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace CamadaDados
{
    public class Country
    {
        #region Metodos

        public static DataTable ObterLista()
        {
            DataTable dataTable = null;

            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = Properties.Settings.Default.ConnectionString;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ListCountry";

                SqlDataReader dataReader = cmd.ExecuteReader(CommandBehavior.SingleResult);

                dataTable = new DataTable();
                dataTable.Load(dataReader);

                con.Close();
            }
            catch (Exception e)
            {
            }
            return dataTable;

        }

        public static bool Gravar(string countryCode, string countryName
            , ref string sErro)
        {

            bool bOk = true;
            sErro = "";
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = Properties.Settings.Default.ConnectionString;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "SaveCountry";

                SqlParameter param = new SqlParameter("CountryCode", SqlDbType.NVarChar, 10);
                param.Value = countryCode;
                cmd.Parameters.Add(param);

                SqlParameter param2 = new SqlParameter("CountryName", SqlDbType.NVarChar, 50);
                param2.Value = countryName;
                cmd.Parameters.Add(param2);

                cmd.ExecuteNonQuery();

                con.Close();
            }
            catch (Exception e)
            {
                sErro = e.Message;
                bOk = false;
            }
            return bOk;

        }

        public static bool Eliminar(string countryCode, ref string sErro)
        {

            bool bOk = true;
            sErro = "";
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = Properties.Settings.Default.ConnectionString;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "DeleteCountry";

                SqlParameter param = new SqlParameter("CountryCode", SqlDbType.NVarChar, 10);
                param.Value = countryCode;
                cmd.Parameters.Add(param);

                cmd.ExecuteNonQuery();

                con.Close();
            }
            catch (Exception e)
            {
                sErro = e.Message;
                bOk = false;
            }
            return bOk;

        }

        #endregion
    }
}
