﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace CamadaDados
{
    public class Association
    {
        #region Metodos

        public static DataTable ObterLista()
        {
            DataTable dataTable = null;

            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = Properties.Settings.Default.ConnectionString;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ListAssociation";

                SqlDataReader dataReader = cmd.ExecuteReader(CommandBehavior.SingleResult);

                dataTable = new DataTable();
                dataTable.Load(dataReader);

                con.Close();
            }
            catch (Exception e)
            {
            }
            return dataTable;

        }

        public static bool ObterAssociation(int associationCode
            , ref string associationName, ref string countryCode, ref string clusterCode
            , ref int memberNumbers, ref string sErro)
        {
            bool bOk = true;
            sErro = "";
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = Properties.Settings.Default.ConnectionString;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GetAssociation";

                SqlParameter param = new SqlParameter("AssociationCode", SqlDbType.Int);
                param.Value = associationCode;
                cmd.Parameters.Add(param);

                SqlDataReader sqlDataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                if (sqlDataReader.HasRows)
                {
                    sqlDataReader.Read();
                    if (!sqlDataReader.IsDBNull(1))
                        associationName = sqlDataReader.GetString(1);

                    if (!sqlDataReader.IsDBNull(2))
                        countryCode = sqlDataReader.GetString(2);

                    if (!sqlDataReader.IsDBNull(3))
                        clusterCode = sqlDataReader.GetString(3);

                    if (!sqlDataReader.IsDBNull(4))
                        memberNumbers = sqlDataReader.GetInt32(4);

                    bOk = true;
                }

                con.Close();
            }
            catch (Exception e)
            {
                sErro = e.Message;
                bOk = false;
            }
            return bOk;
        }


        public static bool Gravar(int associationCode, string associationName
            , string countryCode, string clusterCode, int memberNumbers, ref string sErro)
        {

            bool bOk = true;
            sErro = "";
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = Properties.Settings.Default.ConnectionString;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "SaveAssociation";

                SqlParameter param = new SqlParameter("AssociationCode", SqlDbType.Int);
                param.Value = associationCode;
                cmd.Parameters.Add(param);

                SqlParameter param2 = new SqlParameter("AssociationName", SqlDbType.NVarChar, 80);
                param2.Value = associationName;
                cmd.Parameters.Add(param2);

                SqlParameter param3 = new SqlParameter("CountryCode", SqlDbType.NVarChar, 10);
                param3.Value = countryCode;
                cmd.Parameters.Add(param3);

                SqlParameter param4 = new SqlParameter("ClusterCode", SqlDbType.NVarChar, 10);
                param4.Value = clusterCode;
                cmd.Parameters.Add(param4);

                SqlParameter param5 = new SqlParameter("MemberNumbers", SqlDbType.Int);
                param5.Value = memberNumbers;
                cmd.Parameters.Add(param5);

                cmd.ExecuteNonQuery();

                con.Close();
            }
            catch (Exception e)
            {
                sErro = e.Message;
                bOk = false;
            }
            return bOk;

        }

        public static bool Eliminar(int associationCode, ref string sErro)
        {

            bool bOk = true;
            sErro = "";
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = Properties.Settings.Default.ConnectionString;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "DeleteAssociation";

                SqlParameter param = new SqlParameter("AssociationCode", SqlDbType.Int);
                param.Value = associationCode;
                cmd.Parameters.Add(param);

                cmd.ExecuteNonQuery();

                con.Close();
            }
            catch (Exception e)
            {
                sErro = e.Message;
                bOk = false;
            }
            return bOk;

        }

        #endregion
    }
}
