﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace CamadaDados
{
    public class Cluster
    {
        #region Metodos

        public static DataTable ObterLista()
        {
            DataTable dataTable = null;

            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = Properties.Settings.Default.ConnectionString;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ListCluster";

                SqlDataReader dataReader = cmd.ExecuteReader(CommandBehavior.SingleResult);

                dataTable = new DataTable();
                dataTable.Load(dataReader);

                con.Close();
            }
            catch (Exception e)
            {
            }
            return dataTable;

        }


        public static bool Gravar(string clusterCode, string clusterName, int clusterType
            , ref string sErro)
        {

            bool bOk = true;
            sErro = "";
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = Properties.Settings.Default.ConnectionString;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "SaveCluster";

                SqlParameter param = new SqlParameter("ClusterCode", SqlDbType.NVarChar, 10);
                param.Value = clusterCode;
                cmd.Parameters.Add(param);

                SqlParameter param2 = new SqlParameter("ClusterName", SqlDbType.NVarChar, 90);
                param2.Value = clusterName;
                cmd.Parameters.Add(param2);

                SqlParameter param3 = new SqlParameter("ClusterType", SqlDbType.Int);
                param3.Value = clusterType;
                cmd.Parameters.Add(param3);

                cmd.ExecuteNonQuery();

                con.Close();
            }
            catch (Exception e)
            {
                sErro = e.Message;
                bOk = false;
            }
            return bOk;

        }

        public static bool Eliminar(string clusterCode, ref string sErro)
        {

            bool bOk = true;
            sErro = "";
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = Properties.Settings.Default.ConnectionString;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "DeleteCluster";

                SqlParameter param = new SqlParameter("ClusterCode", SqlDbType.NVarChar, 10);
                param.Value = clusterCode;
                cmd.Parameters.Add(param);

                cmd.ExecuteNonQuery();

                con.Close();
            }
            catch (Exception e)
            {
                sErro = e.Message;
                bOk = false;
            }
            return bOk;

        }

        #endregion
    }
}
