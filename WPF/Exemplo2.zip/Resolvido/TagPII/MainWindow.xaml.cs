﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TagPII
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ButtonWindow11_Click(object sender, RoutedEventArgs e)
        {
            TagPII.Window11 window11 = new TagPII.Window11();
            window11.ShowDialog();
        }

        private void ButtonPais_Click(object sender, RoutedEventArgs e)
        {
            TagPII.Country form = new TagPII.Country();
            form.ShowDialog();
        }

        private void ButtonCluster_Click(object sender, RoutedEventArgs e)
        {
            TagPII.Cluster form = new TagPII.Cluster();
            form.ShowDialog();
        }

        private void ButtonListaAssociacao_Click(object sender, RoutedEventArgs e)
        {
            TagPII.ListaAssociacao lista = new TagPII.ListaAssociacao();
            lista.ShowDialog();
        }

        private void ButtonListaPais_Click(object sender, RoutedEventArgs e)
        {
            TagPII.ListaCountry lista = new TagPII.ListaCountry();
            lista.ShowDialog();
        }

        private void ButtonListaClusters_Click(object sender, RoutedEventArgs e)
        {
            TagPII.ListaCluster lista = new TagPII.ListaCluster();
            lista.ShowDialog();
        }

        private void ButtonAssociacao_Click(object sender, RoutedEventArgs e)
        {
            TagPII.Association form = new TagPII.Association();
            form.ShowDialog();
        }

    }
}
