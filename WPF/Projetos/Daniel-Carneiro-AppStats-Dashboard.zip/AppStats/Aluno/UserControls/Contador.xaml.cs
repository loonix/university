﻿using System.Windows.Controls;


namespace AppStatistics
{
    /// <summary>
    /// Interaction logic for Contador.xaml
    /// </summary>
    public partial class Contador : UserControl
    {
        public Contador()
        {
            InitializeComponent();

        }
    }
}
