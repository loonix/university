﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace CamadaDados
{
    public class Mobilia
    {

        #region Metodos

        public static DataTable ObterLista()
        {
            DataTable dataTable = null;

            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = Properties.Settings.Default.LigacaoBD;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT * FROM Mobilia";

                SqlDataReader dataReader = cmd.ExecuteReader(CommandBehavior.SingleResult);

                dataTable = new DataTable();
                dataTable.Load(dataReader);

                con.Close();
            }
            catch (Exception e)
            {
            }
            return dataTable;

        }

        public static bool Gravar(string identificacao, string descricao
            , string tipoMadeira, string familiaMobilia, int peso, ref string sErro)
        {

            bool bOk = true;
            sErro = "";
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = Properties.Settings.Default.LigacaoBD;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Mobilia_Grava";

                SqlParameter param = new SqlParameter("Identificacao", SqlDbType.NVarChar, 20);
                param.Value = identificacao;
                cmd.Parameters.Add(param);

                SqlParameter param2 = new SqlParameter("Descricao", SqlDbType.NVarChar, 80);
                param2.Value = descricao;
                cmd.Parameters.Add(param2);

                SqlParameter param3 = new SqlParameter("TipoMadeira", SqlDbType.NVarChar, 15);
                param3.Value = tipoMadeira;
                cmd.Parameters.Add(param3);

                SqlParameter param4 = new SqlParameter("FamiliaMobilia", SqlDbType.NVarChar, 15);
                param4.Value = familiaMobilia;
                cmd.Parameters.Add(param4);

                SqlParameter param5 = new SqlParameter("Peso", SqlDbType.Int);
                param5.Value = peso;
                cmd.Parameters.Add(param5);


                cmd.ExecuteNonQuery();

                con.Close();
            }
            catch (Exception e)
            {
                sErro = e.Message;
                bOk = false;
            }
            return bOk;

        }

        #endregion

    }
}
