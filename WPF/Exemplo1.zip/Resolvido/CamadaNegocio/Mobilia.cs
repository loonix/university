﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Data;

namespace CamadaNegocio
{
    public class Mobilia : INotifyPropertyChanged
    {

        #region Propriedades

        private string identificacao;
        public string Identificacao
        {
            get { return identificacao; }
            set
            {
                identificacao = value;
                OnPropertyChanged("Identificacao");
            }
        }

        private string descricao;
        public string Descricao
        {
            get { return descricao; }
            set
            {
                descricao = value;
                OnPropertyChanged("Descricao");
            }
        }

        private string tipoMadeira;
        public string TipoMadeira
        {
            get { return tipoMadeira; }
            set
            {
                tipoMadeira = value;
                OnPropertyChanged("TipoMadeira");
            }
        }

        private string familiaMobilia;
        public string FamiliaMobilia
        {
            get { return familiaMobilia; }
            set
            {
                familiaMobilia = value;
                OnPropertyChanged("FamiliaMobilia");
            }
        }

        private int peso;
        public int Peso
        {
            get { return peso; }
            set
            {
                peso = value;
                OnPropertyChanged("Peso");
            }
        }

        #endregion

        #region Eventos
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }

        #endregion

        #region Metodos

        public bool MobiliaValido(out string erro)
        {
            bool ok = false;
            erro = string.Empty;

            //if (this.Descricao == null || this.FamiliaMobilia == null || this.Identificacao == null || this.TipoMadeira == null)
            if (string.IsNullOrEmpty(this.Descricao) || string.IsNullOrEmpty(this.FamiliaMobilia) || 
                string.IsNullOrEmpty(this.Identificacao) || string.IsNullOrEmpty(this.TipoMadeira))
            {
                erro = "Preencha todos os campos";
            }
            else if ((this.Peso < 0) || (this.Peso > 9999))
            {
                erro = "Nº inválido.";
            }
            else
            {
                ok = true;
            }

            return ok;
        }

        public static DataTable ObterLista()
        {
            return CamadaDados.Mobilia.ObterLista();
        }

        public static MobiliaCollection ObterListaMobilias()
        {
            DataTable dataTable = Mobilia.ObterLista();

            MobiliaCollection mobilias = new MobiliaCollection(dataTable);

            return mobilias;
        }

        public void Novo()
        {
            this.Identificacao = "";
            this.TipoMadeira = "";
            this.Peso = 0;
            this.Descricao = "";
            this.FamiliaMobilia = "";
        }

        public bool Gravar(ref string sErro)
        {
            return CamadaDados.Mobilia.Gravar(this.Identificacao, this.Descricao
                , this.TipoMadeira, this.FamiliaMobilia, this.Peso, ref sErro);
        }

        #endregion


        public bool Eliminar(ref string sErro)
        {
            return CamadaDados.Mobilia.Eliminar(this.identificacao, ref sErro);
        }
    }

    public class MobiliaCollection : Collection<Mobilia>
    {
        #region Construtores

        public MobiliaCollection()
        {
        }

        public MobiliaCollection(DataTable dataTable)
        {
            foreach (DataRow item in dataTable.AsEnumerable())
            {
                Mobilia mobilia = new Mobilia();
                mobilia.Identificacao = item.Field<string>("Identificacao");
                mobilia.Descricao = item.Field<string>("Descricao");
                mobilia.TipoMadeira = item.Field<string>("TipoMadeira");
                mobilia.FamiliaMobilia = item.Field<string>("FamiliaMobilia");
                mobilia.Peso = item.Field<int>("Peso");

                this.Add(mobilia);
            }
        }

        #endregion

    }
}
