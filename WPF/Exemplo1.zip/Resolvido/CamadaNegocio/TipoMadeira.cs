﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Data;

namespace CamadaNegocio
{
    public class TipoMadeira : INotifyPropertyChanged
    {

        #region Construtores

        public TipoMadeira()
        {
            this.codTipoMadeira = "";
            this.descricao = "";
        }

        public TipoMadeira(TipoMadeira tipoMadeira)
        {
            this.Copiar(tipoMadeira);
        }

        #endregion

        #region Propriedades

        private string codTipoMadeira;
        public string CodTipoMadeira
        {
            get { return codTipoMadeira; }
            set
            {
                codTipoMadeira = value;
                OnPropertyChanged("CodTipoMadeira");
            }
        }

        private string descricao;
        public string Descricao
        {
            get { return descricao; }
            set
            {
                descricao = value;
                OnPropertyChanged("Descricao");
            }
        }

        #endregion

        #region Metodos

        public void Copiar(TipoMadeira tipoMadeira)
        {
            if (tipoMadeira != null)
            {
                this.codTipoMadeira = tipoMadeira.CodTipoMadeira;
                this.descricao = tipoMadeira.Descricao;
            }
        }

        #endregion

        #region Eventos
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }

        #endregion

        #region Metodos

        public static DataTable ObterLista()
        {
            return CamadaDados.TipoMadeira.ObterLista();
        }

        public static TipoMadeiraCollection ObterListaTiposMadeira()
        {
            DataTable dataTable = TipoMadeira.ObterLista();

            TipoMadeiraCollection tiposMadeira = new TipoMadeiraCollection(dataTable);

            return tiposMadeira;
        }

        public bool Gravar(ref string sErro)
        {
            return CamadaDados.TipoMadeira.Gravar(this.CodTipoMadeira, this.Descricao, ref sErro);
        }

        #endregion

    }

    public class TipoMadeiraCollection : Collection<TipoMadeira>
    {
        #region Construtores

        public TipoMadeiraCollection()
        {
        }

        public TipoMadeiraCollection(DataTable dataTable)
        {
            foreach (DataRow item in dataTable.AsEnumerable())
            {
                TipoMadeira tipoMadeira = new TipoMadeira();
                tipoMadeira.CodTipoMadeira = item.Field<string>("CodTipoMadeira");
                tipoMadeira.Descricao = item.Field<string>("Descricao");

                this.Add(tipoMadeira);
            }
        }

        #endregion
    }
}
