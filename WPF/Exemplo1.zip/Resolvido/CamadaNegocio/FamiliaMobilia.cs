﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Data;

namespace CamadaNegocio
{
    public class FamiliaMobilia : INotifyPropertyChanged
    {

        #region Construtores

        public FamiliaMobilia()
        {
            this.codFamiliaMobilia = "";
            this.descricao = "";
        }

        #endregion

        #region Propriedades

        private string codFamiliaMobilia;
        public string CodFamiliaMobilia
        {
            get { return codFamiliaMobilia; }
            set
            {
                codFamiliaMobilia = value;
                OnPropertyChanged("CodFamiliaMobilia");
            }
        }

        private string descricao;
        public string Descricao
        {
            get { return descricao; }
            set
            {
                descricao = value;
                OnPropertyChanged("Descricao");
            }
        }

        #endregion

        #region Eventos
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }

        #endregion

        #region Metodos

        public static DataTable ObterLista()
        {
            return CamadaDados.FamiliaMobilia.ObterLista();
        }

        public DataTable ObterLista2()
        {
            return CamadaDados.FamiliaMobilia.ObterLista();
        }

        public static FamiliaMobiliaCollection ObterListaMobilias()
        {
            DataTable dataTable = FamiliaMobilia.ObterLista();

            FamiliaMobiliaCollection familiaMobilias = new FamiliaMobiliaCollection(dataTable);

            return familiaMobilias;
        }

        public bool Gravar(ref string sErro)
        {
            return CamadaDados.FamiliaMobilia.Gravar(this.CodFamiliaMobilia, this.Descricao, ref sErro);
        }

        #endregion

    }

    public class FamiliaMobiliaCollection : Collection<FamiliaMobilia>
    {
        #region Construtores

        public FamiliaMobiliaCollection()
        {
        }

        public FamiliaMobiliaCollection(DataTable dataTable)
        {
            foreach (DataRow item in dataTable.AsEnumerable())
            {
                FamiliaMobilia familiaMobilia = new FamiliaMobilia();
                familiaMobilia.CodFamiliaMobilia = item.Field<string>("CodFamiliaMobilia");
                familiaMobilia.Descricao = item.Field<string>("Descricao");

                this.Add(familiaMobilia);
            }
        }

        #endregion
    }
}
