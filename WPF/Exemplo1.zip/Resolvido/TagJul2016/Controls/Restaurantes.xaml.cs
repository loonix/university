﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TagJul2016.Controls
{
    /// <summary>
    /// Interaction logic for Restaurantes.xaml
    /// </summary>
    public partial class Restaurantes : UserControl
    {
        public Restaurantes()
        {
            InitializeComponent();
        }

        
        private string imagem;
        public string Imagem
        {
            get
            {
                return this.imagem;
            }
            set
            {
                this.imagem = value;
                try
                {
                    this.ImageSource.Source = new BitmapImage(new Uri(value, UriKind.Relative));
                }
                catch (Exception)
                {
                    
                }
            }
        }        

        private string titulo;
        public string Titulo
        {
            get
            {
                return this.titulo;
            }
            set
            {
                this.titulo = value;
                this.TextBlockTitulo.Text = value;
            }
        }

        private string descricao;
        public string Descricao
        {
            get
            {
                return this.descricao;
            }
            set
            {
                this.descricao = value;
                this.TextBlockDescricao.Text = value;
            }
        }
    }
}
