﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TagJul2012
{
    /// <summary>
    /// Interaction logic for WindowListaFamiliaMobilia.xaml
    /// </summary>
    public partial class WindowListaFamiliaMobilia : Window
    {
        #region Propriedades

        public CamadaNegocio.FamiliaMobilia familia { get; set; }

        #endregion

        public WindowListaFamiliaMobilia()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //ListViewFamiliaMobilia.ItemsSource = CamadaNegocio.FamiliaMobilia.ObterLista().DefaultView;
            ListViewFamiliaMobilia.ItemsSource = CamadaNegocio.FamiliaMobilia.ObterListaMobilias();
            /*
            CamadaNegocio.FamiliaMobilia pais = new CamadaNegocio.FamiliaMobilia();
            ListViewFamiliaMobilia.ItemsSource = pais.ObterLista2().DefaultView;
            */
            
            /*            
            CamadaNegocio.FamiliaMobiliaCollection p = new CamadaNegocio.FamiliaMobiliaCollection();

            p.FirstOrDefault(x => x.Descricao == "ABC");

            IEnumerable<CamadaNegocio.FamiliaMobilia> paises = from cc
                                                       in p
                                                   where cc.CodFamiliaMobilia == "IT"
                                                   select cc;
            
            */

        }

        private void ListViewFamiliaMobilia_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (ListViewFamiliaMobilia.SelectedIndex >= 0)
            {
                CamadaNegocio.FamiliaMobilia familiaSelecionada = (CamadaNegocio.FamiliaMobilia)ListViewFamiliaMobilia.SelectedItem;
                this.familia = familiaSelecionada;
                this.Close();
             }
        }

        private void ButtonEditar_Click(object sender, RoutedEventArgs e)
        {
            if (ListViewFamiliaMobilia.SelectedIndex >= 0)
            {
                CamadaNegocio.FamiliaMobilia familiaSelecionada = (CamadaNegocio.FamiliaMobilia)ListViewFamiliaMobilia.SelectedItem;
                WindowFamiliaMobiliaEditar w = new WindowFamiliaMobiliaEditar(familiaSelecionada);
                w.ShowDialog();
                ListViewFamiliaMobilia.ItemsSource = CamadaNegocio.FamiliaMobilia.ObterListaMobilias();
            } 
        }
    }
}
