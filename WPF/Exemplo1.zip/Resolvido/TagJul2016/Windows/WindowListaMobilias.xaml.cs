﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TagJul2012
{
    /// <summary>
    /// Interaction logic for WindowListaMobilias.xaml
    /// </summary>
    public partial class WindowListaMobilias : Window
    {

        #region Propriedades

        private CamadaNegocio.MobiliaCollection mobilias { get; set; }

        #endregion

        public WindowListaMobilias()
        {
            InitializeComponent();
        }

        #region Metodos

        private void MostrarListaCarros()
        {
            this.mobilias = CamadaNegocio.Mobilia.ObterListaMobilias();

            this.ListBoxMobilias.ItemsSource = this.mobilias;
        }

        #endregion
        
        #region Eventos

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.MostrarListaCarros();
        }

        #endregion


    }
}
