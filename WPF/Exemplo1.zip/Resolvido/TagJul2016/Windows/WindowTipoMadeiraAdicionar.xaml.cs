﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TagJul2012
{
    /// <summary>
    /// Interaction logic for WindowTipoMadeiraAdicionar.xaml
    /// </summary>
    public partial class WindowTipoMadeiraAdicionar : Window
    {
        #region Propriedades

        public CamadaNegocio.TipoMadeira TipoMadeira { get; set; }

        #endregion

        #region Construtores

        public WindowTipoMadeiraAdicionar()
        {
            InitializeComponent();
            this.DataContext = this.TipoMadeira;
        }

        #endregion

        #region Metodos

        private void GravarRegisto()
        {
            string sErro = string.Empty;
            CamadaNegocio.TipoMadeira tipoMadeira = (CamadaNegocio.TipoMadeira)this.DataContext;

            if (tipoMadeira.Gravar(ref sErro))
            {
                MessageBox.Show("Gravado com sucesso.");
            }
            else
            {
                MessageBox.Show(string.Format("Erro {0}", sErro));
            }
        }

        #endregion

        #region Eventos

        private void ButtonGravar_Click(object sender, RoutedEventArgs e)
        {
            this.GravarRegisto();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (this.TipoMadeira != null)
            {
                this.DataContext = this.TipoMadeira;
            }
        }

        #endregion

    }
}
