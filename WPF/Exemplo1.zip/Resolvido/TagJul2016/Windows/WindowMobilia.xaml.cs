﻿using CamadaNegocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TagJul2012
{
    /// <summary>
    /// Interaction logic for WindowMobilia.xaml
    /// </summary>
    public partial class WindowMobilia : Window
    {

        #region Propriedades

        public CamadaNegocio.Mobilia Mobilia { get; set; }

        #endregion

        public WindowMobilia()
        {
            InitializeComponent();
            if (this.Mobilia == null)
                this.Mobilia = new CamadaNegocio.Mobilia();

            this.DataContext = this.Mobilia;
        }

        #region Metodos

        private void NovoRegisto()
        {
            CamadaNegocio.Mobilia mobilia = (CamadaNegocio.Mobilia)this.DataContext;
            mobilia.Novo();
        }

        private void GravarRegisto()
        {
            string sErro = string.Empty;
            CamadaNegocio.Mobilia mobilia = (CamadaNegocio.Mobilia)this.DataContext;

            if (mobilia.MobiliaValido(out sErro))
            {
                if (mobilia.Gravar(ref sErro))
                {
                    MessageBox.Show("Gravado com sucesso.");
                }
                else
                {
                    MessageBox.Show(string.Format("Erro {0}", sErro));
                }
            }
            else
            {
                MessageBox.Show(string.Format("Erro {0}", sErro));
            }
        }

        private bool MobiliaValido(Mobilia mobilia)
        {
            bool ok = false;
            if (mobilia.Descricao == null || mobilia.FamiliaMobilia == null || mobilia.Identificacao == null || mobilia.TipoMadeira == null)
            {
                MessageBox.Show("Preencha todos os campos");
            }
            else if ((mobilia.Peso < 0) || (mobilia.Peso > 9999))
            {
                MessageBox.Show("Nº inválido.");
            }
            else
            {
                ok = true;
            }

            return ok;
        }

        private void EliminarRegisto()
        {
            string sErro = string.Empty;
            CamadaNegocio.Mobilia mobilia = (CamadaNegocio.Mobilia)this.DataContext;

            if (mobilia.Eliminar(ref sErro))
            {
                MessageBox.Show("Eliminado com sucesso.");
            }
            else
            {
                MessageBox.Show(string.Format("Erro {0}", sErro));
            }
        }


        #endregion

        #region Eventos

        private void ButtonTipoMadeira_Click(object sender, RoutedEventArgs e)
        {
            WindowListaTipoMadeira w = new WindowListaTipoMadeira();
            w.ShowDialog();

            if (w.tipoMadeira != null)
            {
                this.txtTipoMadeira.Text = w.tipoMadeira.CodTipoMadeira;
                TextBlockDescricaoTipoMadeira.Text = w.tipoMadeira.Descricao;
            }
            w = null;
        }        

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (this.Mobilia != null)
            {
                this.DataContext = this.Mobilia;
            }
        }      

        private void ButtonSair_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void ButtonFamiliaMobilia_Click(object sender, RoutedEventArgs e)
        {
            WindowListaFamiliaMobilia w = new WindowListaFamiliaMobilia();
            w.ShowDialog();

            if (w.familia != null)
            {
                this.txtFamiliaMobilia.Text = w.familia.CodFamiliaMobilia;
            }
            w = null;
        }

        private void New_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            this.NovoRegisto();
        }

        private void Save_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            this.GravarRegisto();
        }

        private void Close_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            this.Close();
        }

        private void Delete_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            this.EliminarRegisto();
        }

        private void VerLista_Click(object sender, RoutedEventArgs e)
        {
            WindowListaMobilias w = new WindowListaMobilias();
            w.ShowDialog();
        }
        #endregion

       
    }
}
