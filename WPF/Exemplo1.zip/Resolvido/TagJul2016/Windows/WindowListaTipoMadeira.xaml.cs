﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TagJul2012
{
    /// <summary>
    /// Interaction logic for WindowListaTipoMadeira.xaml
    /// </summary>
    public partial class WindowListaTipoMadeira : Window
    {
        #region Propriedades

        private CamadaNegocio.TipoMadeiraCollection tiposMadeira { get; set; }

        public CamadaNegocio.TipoMadeira tipoMadeira { get; set; }

        #endregion

        #region Construtores

        public WindowListaTipoMadeira()
        {
            InitializeComponent();
        }

        #endregion

        #region Metodos

        private void MostrarListaTipoMadeira()
        {
            this.tiposMadeira = CamadaNegocio.TipoMadeira.ObterListaTiposMadeira();

            this.ListViewTipoMadeira.ItemsSource = this.tiposMadeira;
        }

        #endregion

        #region Eventos

        private void ListViewTipoMadeira_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (ListViewTipoMadeira.SelectedIndex >= 0)
            {
                CamadaNegocio.TipoMadeira tipoMadeiraSelecionado = (CamadaNegocio.TipoMadeira)ListViewTipoMadeira.SelectedItem;
                this.tipoMadeira = tipoMadeiraSelecionado;
                this.Close();
             }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.MostrarListaTipoMadeira();
        }

        private void ButtonEditar_Click(object sender, RoutedEventArgs e)
        {
          //v1 CamadaNegocio.Marca marcaSelecionado = (CamadaNegocio.Marca)ListViewMarca.SelectedItem;
          //v2 CamadaNegocio.Marca marcaSelecionado = new CamadaNegocio.Marca();
          //v2 marcaSelecionado = (CamadaNegocio.Marca)ListViewMarca.SelectedItem;
            
          //CamadaNegocio.Marca marcaSelecionado = new CamadaNegocio.Marca();
          //marcaSelecionado.Codigo = ((CamadaNegocio.Marca)ListViewMarca.SelectedItem).Codigo;
          //marcaSelecionado.Descricao = ((CamadaNegocio.Marca)ListViewMarca.SelectedItem).Descricao;

            CamadaNegocio.TipoMadeira itemSelecionado = (CamadaNegocio.TipoMadeira)ListViewTipoMadeira.SelectedItem;
            CamadaNegocio.TipoMadeira marcaSelecionado = new CamadaNegocio.TipoMadeira(itemSelecionado);

            WindowTipoMadeiraAdicionar w = new WindowTipoMadeiraAdicionar();
            w.TipoMadeira = marcaSelecionado;
            w.ShowDialog();
            this.MostrarListaTipoMadeira();
        }

        #endregion



    }
}
