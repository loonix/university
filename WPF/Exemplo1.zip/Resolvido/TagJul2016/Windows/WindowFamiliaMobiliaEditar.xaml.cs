﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TagJul2012
{
    /// <summary>
    /// Interaction logic for WindowFamiliaMobiliaEditar.xaml
    /// </summary>
    public partial class WindowFamiliaMobiliaEditar : Window
    {
        #region Propriedades

        public CamadaNegocio.FamiliaMobilia FamiliaMobilia { get; set; }

        #endregion

        #region Construtores

        public WindowFamiliaMobiliaEditar()
        {
            InitializeComponent();
            this.DataContext = this.FamiliaMobilia;
        }

        public WindowFamiliaMobiliaEditar(CamadaNegocio.FamiliaMobilia familiaSelecionada)
            :this()
        {
            this.FamiliaMobilia = familiaSelecionada;
            this.DataContext = this.FamiliaMobilia;
        }

        #endregion

        #region Eventos

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (this.FamiliaMobilia != null)
            {
                this.DataContext = this.FamiliaMobilia;
            }
        }
        #endregion

        private void ButtonGravar_Click(object sender, RoutedEventArgs e)
        {
            this.GravarRegisto();
        }

        private void GravarRegisto()
        {
            {
                string sErro = string.Empty;
                CamadaNegocio.FamiliaMobilia familiaMobilia = (CamadaNegocio.FamiliaMobilia)this.DataContext;

                if (familiaMobilia.Gravar(ref sErro))
                {
                    MessageBox.Show("Gravado com sucesso.");
                }
                else
                {
                    MessageBox.Show(string.Format("Erro {0}", sErro));
                }
            }

        }



    }
}
