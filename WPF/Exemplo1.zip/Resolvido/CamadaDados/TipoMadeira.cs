﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace CamadaDados
{
    public class TipoMadeira
    {

        #region Metodos

        public static DataTable ObterLista()
        {
            DataTable dataTable = null;

            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = Properties.Settings.Default.LigacaoBD;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT * FROM TipoMadeira";

                SqlDataReader dataReader = cmd.ExecuteReader(CommandBehavior.SingleResult);

                dataTable = new DataTable();
                dataTable.Load(dataReader);

                con.Close();
            }
            catch (Exception e)
            {
            }
            return dataTable;

        }

        public static bool Gravar(string codTipoMadeira, string descricao, ref string sErro)
        {

            bool bOk = true;
            sErro = "";
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = Properties.Settings.Default.LigacaoBD;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "TipoMadeira_Grava";

                SqlParameter param = new SqlParameter("CodTipoMadeira", SqlDbType.NVarChar, 15);
                param.Value = codTipoMadeira;
                cmd.Parameters.Add(param);

                SqlParameter param2 = new SqlParameter("Descricao", SqlDbType.NVarChar, 90);
                param2.Value = descricao;
                cmd.Parameters.Add(param2);

                cmd.ExecuteNonQuery();

                con.Close();
            }
            catch (Exception e)
            {
                sErro = e.Message;
                bOk = false;
            }
            return bOk;

        }

        #endregion

    }
}
