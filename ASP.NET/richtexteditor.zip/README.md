Rich Text Editor build v1.0.0
======================================

In order to start using Rich Text Editor, configure or customize them, please visit http://richtexteditor.com/docs/

## License

For information regarding the license please read [Licensing Info](http://richtexteditor.com/license.aspx).
